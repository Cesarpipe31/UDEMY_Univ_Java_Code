package domain;

public class Empleado extends Persona{
    
}
