package test;

import domain.Empleado;

public class TestHerencia {
    public static void main(String[] args) {
        Empleado empleado1 = new Empleado();
        System.out.println("empleado1 = " + empleado1);
    }
}
